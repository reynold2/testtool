#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include<qfiledialog.h>
#include<QMessageBox.h>
#include <QDebug>
#include <QDateTime>
#include <QThreadPool>
#include <QMainWindow>
#include "ui_mainwindow.h"
#include"documentoperation.h"
#include "myrunable.h"
#include "mythread.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_FileButton_clicked();

    void on_Button_FilePath_clicked();

    void on_MianButton_clicked();

    void on_ContextButton_clicked();

//    void on_progressBar_valueChanged(int value);

    void showMsg(const QString &msg);

private:
    Ui::MainWindow *ui;
    MyThread myThread;
public:
    vector<string> WordFileNamePath_docx;
    vector<string> ExcelFileNamePath_xlsx;
    vector<string> FileNamePath;
};

#endif // MAINWINDOW_H
